import { initializeApp, cert } from "firebase-admin/app"
import { getFirestore } from "firebase-admin/firestore"
import * as serviceAccount from "./serviceAccountKey.json"
import cotizadorData from "./firestore_config_completa.json"

initializeApp({
  credential: cert(serviceAccount as any)
})

const db = getFirestore()

async function upload() {
  try {
    await db.collection("cotizador_config").doc("bolivia").set(cotizadorData)
    console.log("✅ Subido correctamente a Firestore con Admin SDK")
  } catch (error) {
    console.error("❌ Error al subir:", error)
  }
}

upload()
