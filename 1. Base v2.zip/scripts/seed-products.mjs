import { initializeApp } from "firebase/app"
import { getFirestore, collection, doc, setDoc } from "firebase/firestore"

// Firebase configuration
const firebaseConfig = {
  apiKey: process.env.NEXT_PUBLIC_FIREBASE_API_KEY,
  authDomain: process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN,
  projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID,
  storageBucket: process.env.NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: process.env.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID,
  appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID,
  measurementId: process.env.NEXT_PUBLIC_FIREBASE_MEASUREMENT_ID
}

// Initialize Firebase
const app = initializeApp(firebaseConfig)
const db = getFirestore(app)

async function seedProducts() {
  try {
    console.log("🌱 Iniciando seeding de productos...")

    // 1. Panel único de 590W
    const panelData = {
      id: "panel-590w",
      name: "Panel Solar 590W",
      brand: "Tier 1 Solar",
      power: 0.59, // kW
      efficiency: 0.22, // 22%
      warranty: 25,
      price: 0.75, // $0.75 por watt
      pricePerWatt: 0.75,
      totalPrice: 442.5, // 590W × $0.75
      isActive: true,
      createdAt: new Date(),
      updatedAt: new Date()
    }

    await setDoc(doc(db, "panels", "panel-590w"), panelData)
    console.log("✅ Panel 590W creado")

    // 2. Batería única
    const batteryData = {
      id: "battery-main",
      name: "Batería Litio 10kWh",
      brand: "Premium Energy",
      capacity: 10, // kWh
      voltage: 48, // V
      cycles: 6000,
      warranty: 10,
      price: 8000,
      isActive: true,
      createdAt: new Date(),
      updatedAt: new Date()
    }

    await setDoc(doc(db, "batteries", "battery-main"), batteryData)
    console.log("✅ Batería creada")

    // 3. Inversores con precios únicos
    const inverters = [
      { id: "inv-3kw", name: "Inversor 3kW", power: 3.0, price: 800 },
      { id: "inv-5kw", name: "Inversor 5kW", power: 5.0, price: 1200 },
      { id: "inv-8kw", name: "Inversor 8kW", power: 8.0, price: 1800 },
      { id: "inv-10kw", name: "Inversor 10kW", power: 10.0, price: 2200 },
      { id: "inv-15kw", name: "Inversor 15kW", power: 15.0, price: 3000 },
      { id: "inv-20kw", name: "Inversor 20kW", power: 20.0, price: 3800 },
      { id: "inv-30kw", name: "Inversor 30kW", power: 30.0, price: 5500 },
      { id: "inv-50kw", name: "Inversor 50kW", power: 50.0, price: 8500 },
      { id: "inv-100kw", name: "Inversor 100kW", power: 100.0, price: 15000 }
    ]

    for (const inverter of inverters) {
      const inverterData = {
        ...inverter,
        brand: "Premium Inverters",
        efficiency: 0.97,
        warranty: 10,
        isActive: true,
        createdAt: new Date(),
        updatedAt: new Date()
      }
      
      await setDoc(doc(db, "inverters", inverter.id), inverterData)
      console.log(`✅ ${inverter.name} creado`)
    }

    // 4. Configuración del sistema
    const systemPricingData = {
      id: "default",
      // Radiación solar por departamento (kWh/m²/día)
      solarRadiationByDepartment: {
        "Santa Cruz": 5.8,
        "Beni": 5.8,
        "Pando": 5.8,
        "Cochabamba": 5.4,
        "Chuquisaca": 5.4,
        "Tarija": 5.4,
        "La Paz": 4.9,
        "Oruro": 4.9,
        "Potosí": 4.9
      },
      // Costos de transporte por departamento
      transportCostsByDepartment: {
        "Santa Cruz": 0,    // Base
        "Beni": 150,
        "Pando": 200,
        "Chuquisaca": 100,
        "Tarija": 120,
        "La Paz": 250,
        "Cochabamba": 180,
        "Oruro": 220,
        "Potosí": 200
      },
      // Multiplicadores por sector
      sectorMultipliers: {
        "residential": { multiplier: 1.0, name: "Residencial" },
        "commercial": { multiplier: 1.1, name: "Comercial" },
        "industrial": { multiplier: 1.2, name: "Industrial" },
        "public": { multiplier: 0.95, name: "Público" },
        "agricultural": { multiplier: 1.05, name: "Agrícola" }
      },
      // Porcentajes adicionales
      installationCostPercentage: 0.30, // 30% instalación
      additionalMaterialsPercentage: 0.12, // 12% materiales adicionales
      
      // Datos para cálculos
      electricityRate: 0.12, // $0.12 por kWh
      co2FactorPerKwh: 0.5, // kg CO2 por kWh
      
      createdAt: new Date(),
      updatedAt: new Date()
    }

    await setDoc(doc(db, "system_pricing", "default"), systemPricingData)
    console.log("✅ Configuración del sistema creada")

    console.log("\n🎉 ¡Seeding completado exitosamente!")
    console.log("\n📊 Productos creados:")
    console.log("   • 1 Panel de 590W ($442.50)")
    console.log("   • 1 Batería de 10kWh ($8,000)")
    console.log("   • 9 Inversores (3kW a 100kW)")
    console.log("   • Configuración de radiación solar")
    console.log("   • Costos de transporte por departamento")
    console.log("   • Multiplicadores por sector")

  } catch (error) {
    console.error("❌ Error durante el seeding:", error)
    process.exit(1)
  }
}

// Ejecutar el seeding
seedProducts()
