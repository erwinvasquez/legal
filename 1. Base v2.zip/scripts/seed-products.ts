import { initializeApp } from "firebase/app"
import { getFirestore, doc, setDoc, serverTimestamp } from "firebase/firestore"

// Configuración de Firebase (usar las mismas variables de entorno)
const firebaseConfig = {
  apiKey: process.env.NEXT_PUBLIC_FIREBASE_API_KEY,
  authDomain: process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN,
  projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID,
  storageBucket: process.env.NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: process.env.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID,
  appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID,
  measurementId: process.env.NEXT_PUBLIC_FIREBASE_MEASUREMENT_ID,
}

// Inicializar Firebase
const app = initializeApp(firebaseConfig)
const db = getFirestore(app)

// Panel principal de 590W con precio único
const panelData = {
  id: "panel-590w",
  name: "Panel Solar 590W",
  brand: "Tier 1 Solar",
  power: 0.59, // kW
  efficiency: 0.22, // 22%
  pricePerWatt: 0.75, // $0.75 por watt
  warranty: 25,
  dimensions: { width: 2.1, height: 1.3, depth: 0.04 },
  weight: 32,
  isActive: true,
}

// Batería principal
const batteryData = {
  id: "battery-main",
  name: "Batería Litio 10kWh",
  brand: "Tesla Powerwall",
  capacity: 10, // kWh
  voltage: 48, // V
  price: 8000, // USD
  warranty: 10, // años
  cycleLife: 6000,
  isActive: true,
}

// Inversores con precios únicos
const invertersData = [
  {
    id: "inv-3kw",
    name: "Inversor String 3kW",
    brand: "SolarEdge",
    power: 3.0,
    efficiency: 0.97,
    price: 800,
    type: "string",
    warranty: 12,
    maxPanels: 12,
    isActive: true,
  },
  {
    id: "inv-5kw",
    name: "Inversor String 5kW",
    brand: "SMA",
    power: 5.0,
    efficiency: 0.98,
    price: 1200,
    type: "string",
    warranty: 15,
    maxPanels: 20,
    isActive: true,
  },
  {
    id: "inv-8kw",
    name: "Inversor String 8kW",
    brand: "Fronius",
    power: 8.0,
    efficiency: 0.98,
    price: 1800,
    type: "string",
    warranty: 15,
    maxPanels: 32,
    isActive: true,
  },
  {
    id: "inv-10kw",
    name: "Inversor String 10kW",
    brand: "Huawei",
    power: 10.0,
    efficiency: 0.98,
    price: 2200,
    type: "string",
    warranty: 10,
    maxPanels: 40,
    isActive: true,
  },
  {
    id: "inv-15kw",
    name: "Inversor String 15kW",
    brand: "SolarEdge",
    power: 15.0,
    efficiency: 0.97,
    price: 3200,
    type: "string",
    warranty: 12,
    maxPanels: 60,
    isActive: true,
  },
  {
    id: "inv-20kw",
    name: "Inversor String 20kW",
    brand: "SMA",
    power: 20.0,
    efficiency: 0.98,
    price: 4000,
    type: "string",
    warranty: 15,
    maxPanels: 80,
    isActive: true,
  },
  {
    id: "inv-30kw",
    name: "Inversor String 30kW",
    brand: "ABB",
    power: 30.0,
    efficiency: 0.98,
    price: 5800,
    type: "string",
    warranty: 20,
    maxPanels: 120,
    isActive: true,
  },
  {
    id: "inv-50kw",
    name: "Inversor Central 50kW",
    brand: "ABB",
    power: 50.0,
    efficiency: 0.98,
    price: 8000,
    type: "central",
    warranty: 20,
    maxPanels: 200,
    isActive: true,
  },
  {
    id: "inv-100kw",
    name: "Inversor Central 100kW",
    brand: "Schneider",
    power: 100.0,
    efficiency: 0.99,
    price: 15000,
    type: "central",
    warranty: 25,
    maxPanels: 400,
    isActive: true,
  },
]

// Configuración de precios del sistema
const systemPricingData = {
  id: "default",
  solarRadiationByDepartment: {
    // Grupo de alta radiación
    "Santa Cruz": 5.8,
    Beni: 5.8,
    Pando: 5.8,
    // Grupo de radiación media
    Cochabamba: 5.4,
    Chuquisaca: 5.4,
    Tarija: 5.4,
    // Grupo de radiación baja
    "La Paz": 4.9,
    Oruro: 4.9,
    Potosí: 4.9,
  },
  sectorMultipliers: {
    residential: 1.0, // Residencial - precio base
    commercial: 1.1, // Comercial - 10% más
    industrial: 1.2, // Industrial - 20% más
    public: 0.95, // Público - 5% descuento
    agricultural: 1.05, // Agrícola - 5% más
  },
  transportCosts: {
    // Santa Cruz es base (0 costo adicional)
    "Santa Cruz": 0,
    // Departamentos cercanos
    Beni: 150,
    Pando: 200,
    Chuquisaca: 100,
    Tarija: 120,
    // Departamentos lejanos
    "La Paz": 250,
    Cochabamba: 180,
    Oruro: 220,
    Potosí: 200,
  },
  installationCostPercentage: 0.3, // 30% del costo de paneles
  additionalMaterialsPercentage: 0.12, // 12% para cables, estructuras, etc.
  electricityRate: 0.12, // $0.12 por kWh
  co2FactorPerKwh: 0.5, // 0.5 kg CO2 por kWh
  isActive: true,
}

async function seedDatabase() {
  try {
    console.log("🌱 Iniciando población de base de datos...")

    // Crear panel principal
    console.log("📦 Creando panel solar principal...")
    await setDoc(doc(db, "panels", panelData.id), {
      ...panelData,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    })
    console.log(`✅ Panel creado: ${panelData.name}`)

    // Crear batería principal
    console.log("🔋 Creando batería principal...")
    await setDoc(doc(db, "batteries", batteryData.id), {
      ...batteryData,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    })
    console.log(`✅ Batería creada: ${batteryData.name}`)

    // Crear inversores
    console.log("⚡ Creando inversores...")
    for (const inverter of invertersData) {
      await setDoc(doc(db, "inverters", inverter.id), {
        ...inverter,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      })
      console.log(`✅ Inversor creado: ${inverter.name}`)
    }

    // Crear configuración de precios
    console.log("💰 Creando configuración de precios...")
    await setDoc(doc(db, "system_pricing", "default"), {
      ...systemPricingData,
      updatedAt: serverTimestamp(),
    })
    console.log("✅ Configuración de precios creada")

    console.log("🎉 ¡Base de datos poblada exitosamente!")
    console.log(`📊 Resumen:`)
    console.log(`   - 1 panel solar (590W) con precio único`)
    console.log(`   - 1 batería principal (10kWh)`)
    console.log(`   - ${invertersData.length} inversores con precios únicos`)
    console.log(`   - Costos de transporte por departamento`)
    console.log(`   - 5 sectores configurados`)
  } catch (error) {
    console.error("❌ Error poblando la base de datos:", error)
    throw error
  }
}

// Ejecutar el script
seedDatabase()
  .then(() => {
    console.log("✅ Script completado exitosamente")
    process.exit(0)
  })
  .catch((error) => {
    console.error("❌ Error en el script:", error)
    process.exit(1)
  })

