import { initializeApp } from "firebase/app"
import { getFirestore, doc, setDoc } from "firebase/firestore"

// Configuración de Firebase (usa las mismas variables de entorno)
const firebaseConfig = {
  apiKey: process.env.NEXT_PUBLIC_FIREBASE_API_KEY,
  authDomain: process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN,
  projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID,
  storageBucket: process.env.NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: process.env.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID,
  appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID,
  measurementId: process.env.NEXT_PUBLIC_FIREBASE_MEASUREMENT_ID,
}

// Inicializar Firebase
const app = initializeApp(firebaseConfig)
const db = getFirestore(app)

// Datos de configuración del cotizador con la nueva estructura
const cotizadorConfig = {
  panels: [
    {
      model: "SPDG630-N132R12",
      power_watt: 630,
      power_kw: 0.63,
      type: "bifacial",
      efficiency: 23.32,
      dimensions_mm: [2382, 1134, 30],
      voltage_vmp: 41.7,
      current_imp: 15.11,
      voltage_voc: 49.73,
      current_isc: 15.99,
      weight_kg: 32.4,
      certifications: ["IEC61215", "IEC61730", "TÜV", "CE", "UL"],
      warranty: {
        product_years: 25,
        performance_years: 30,
        power_after_30_years: 87.4,
      },
      price_usd: 315, // Precio estimado por panel
    },
  ],
  batteries: [
    {
      model: "LFP-5kWh-LV",
      technology: "LFP",
      voltage: 51.2,
      capacity_kWh: 5.12,
      usable_kWh: 4.6,
      max_discharge_kw: 2.5,
      peak_discharge_kw: 2.9,
      weight_kg: 58,
      dimensions_mm: [490, 650, 196],
      cycles: 6000,
      dod: 90,
      communication: ["CAN", "RS485"],
      ip_rating: "IP65",
      warranty_years: 10,
      price_usd: 2560,
    },
    {
      model: "LFP-10kWh-LV",
      technology: "LFP",
      voltage: 51.2,
      capacity_kWh: 10.24,
      usable_kWh: 9.2,
      max_discharge_kw: 5,
      peak_discharge_kw: 5.8,
      weight_kg: 109,
      dimensions_mm: [585, 995, 205],
      cycles: 6000,
      dod: 90,
      communication: ["CAN", "RS485"],
      ip_rating: "IP65",
      warranty_years: 10,
      price_usd: 5120,
    },
  ],
  radiation_by_department: {
    "Santa Cruz": 5.8,
    "La Paz": 4.9,
    Cochabamba: 5.4,
    Potosí: 5.2,
    Chuquisaca: 5.3,
    Oruro: 5.1,
    Tarija: 5.5,
    Beni: 5.0,
    Pando: 4.8,
    Desconocido: 5.2,
  },
  costFactors: {
    fixedCosts: {
      tablero: 282.0,
      aterramiento: 215.5,
      proyecto: 150.0,
      pilastra: 400.0,
      cableado: 960.0,
      instalacion_inversor: 93.75,
    },
    variableCosts: {
      utilidad: 0.40,    // 40%
      comision: 0.03,    // 3%
      it: 0.03,          // 3%
      iva: 0.13,         // 13%
    },
    transportPerKg: {
      "Santa Cruz": 0.0,
      "La Paz": 1.5,
      Cochabamba: 1.5,
      Oruro: 1.5,
      Potosí: 1.5,
      Tarija: 1.5,
      Chuquisaca: 1.5,
      Beni: 1.5,
      Pando: 1.5,
    },
    exchangeRate: 6.9, // Tipo de cambio Bs a USD
  },
  electricityRates: {
    residential: {
      minCharge_kWh: 15,
      minCharge_Bs: 13.726,
      tiers: [
        { from: 16, to: 120, rate_Bs: 0.758 },
        { from: 121, to: 300, rate_Bs: 0.969 },
        { from: 301, to: 500, rate_Bs: 1.020 },
        { from: 501, to: 1000, rate_Bs: 1.068 },
        { from: 1001, to: null, rate_Bs: 1.479 }
      ],
      tarifaDignidad: {
        max_kWh: 70,
        discountPercent: 25
      }
    },
    commercial: {
      minCharge_kWh: 20,
      minCharge_Bs: 24.117,
      tiers: [
        { from: 1, to: 120, rate_Bs: 1.091 },
        { from: 121, to: 300, rate_Bs: 1.236 },
        { from: 301, to: null, rate_Bs: 1.765 }
      ]
    },
    industrial: {
      note: "Faltan datos exactos de tarifa escalonada. Se recomienda consultar AETN.",
      flatEstimate_Bs_per_kWh: 1.16
    }
  },
  inverters: [
    {
      Modelo: "SUN-6K-G05P1-EU-AM2",
      marca: "Deye",
      power_kW: 6.0,
      phase: "P1",
      version: "G05P1",
      price: 706.5,
    },
    {
      Modelo: "SUN-7.5K-G02P1-EU-AM2",
      marca: "Deye",
      power_kW: 7.5,
      phase: "P1",
      version: "G02P1",
      price: 889.5,
    },
    {
      Modelo: "SUN-8K-G02P1-EU-AM2",
      marca: "Deye",
      power_kW: 8.0,
      phase: "P1",
      version: "G02P1",
      price: 900.0,
    },
    {
      Modelo: "SUN-10K-G02P1-EU-AM2",
      marca: "Deye",
      power_kW: 10.0,
      phase: "P1",
      version: "G02P1",
      price: 964.5,
    },
    {
      Modelo: "SUN-2K-G04P1-EU-AM1",
      marca: "Deye",
      power_kW: 2.0,
      phase: "P1",
      version: "G04P1",
      price: 439.5,
    },
    {
      Modelo: "SUN-3K-G04P1-EU-AM1",
      marca: "Deye",
      power_kW: 3.0,
      phase: "P1",
      version: "G04P1",
      price: 471.0,
    },
    {
      Modelo: "SUN-4K-G06P3-EU-AM2-P1",
      marca: "Deye",
      power_kW: 4.0,
      phase: "P3",
      version: "G06P3",
      price: 721.5,
    },
    {
      Modelo: "SUN-5K-G06P3-EU-AM2-P1",
      marca: "Deye",
      power_kW: 5.0,
      phase: "P3",
      version: "G06P3",
      price: 745.5,
    },
    {
      Modelo: "SUN-6K-G06P3-EU-AM2-P2",
      marca: "Deye",
      power_kW: 6.0,
      phase: "P3",
      version: "G06P3",
      price: 760.5,
    },
    {
      Modelo: "SUN-7K-G06P3-EU-AM2-P1",
      marca: "Deye",
      power_kW: 7.0,
      phase: "P3",
      version: "G06P3",
      price: 771.0,
    },
    {
      Modelo: "SUN-8K-G06P3-EU-AM2-P1",
      marca: "Deye",
      power_kW: 8.0,
      phase: "P3",
      version: "G06P3",
      price: 793.5,
    },
    {
      Modelo: "SUN-10K-G06P3-EU-AM2-P1",
      marca: "Deye",
      power_kW: 10.0,
      phase: "P3",
      version: "G06P3",
      price: 834.0,
    },
    {
      Modelo: "SUN-12K-G06P3-EU-AM2-P1",
      marca: "Deye",
      power_kW: 12.0,
      phase: "P3",
      version: "G06P3",
      price: 879.0,
    },
    {
      Modelo: "SUN-15K-G06P3-EU-AM2-P1",
      marca: "Deye",
      power_kW: 15.0,
      phase: "P3",
      version: "G06P3",
      price: 1071.0,
    },
    {
      Modelo: "SUN-60K-G04P3-EU-AM4",
      marca: "Deye",
      power_kW: 60.0,
      phase: "P3",
      version: "G04P3",
      price: 2953.5,
    },
    {
      Modelo: "SUN-70K-G04P3-EU-AM4",
      marca: "Deye",
      power_kW: 70.0,
      phase: "P3",
      version: "G04P3",
      price: 2956.5,
    },
    {
      Modelo: "SUN-75K-G04P3-EU-AM4",
      marca: "Deye",
      power_kW: 75.0,
      phase: "P3",
      version: "G04P3",
      price: 3064.5,
    },
    {
      Modelo: "SUN-80K-G04P3-EU-AM4",
      marca: "Deye",
      power_kW: 80.0,
      phase: "P3",
      version: "G04P3",
      price: 3129.0,
    },
    {
      Modelo: "SUN-120K-G01P3-EU-AM8",
      marca: "Deye",
      power_kW: 120.0,
      phase: "P3",
      version: "G01P3",
      price: 4731.0,
    },
    {
      Modelo: "SUN-125K-G01P3-EU-AM8",
      marca: "Deye",
      power_kW: 125.0,
      phase: "P3",
      version: "G01P3",
      price: 4822.5,
    },
    {
      Modelo: "SUN-130K-G01P3-EU-AM8",
      marca: "Deye",
      power_kW: 130.0,
      phase: "P3",
      version: "G01P3",
      price: 5002.5,
    },
    {
      Modelo: "SUN-135K-G01P3-EU-AM8",
      marca: "Deye",
      power_kW: 135.0,
      phase: "P3",
      version: "G01P3",
      price: 5226.0,
    },
    {
      Modelo: "SUN-136K-G01P3-EU-AM8",
      marca: "Deye",
      power_kW: 136.0,
      phase: "P3",
      version: "G01P3",
      price: 5338.5,
    },
  ],
}

async function seedCotizadorConfig() {
  try {
    console.log("🌱 Iniciando seed de configuración del cotizador...")

    // Crear documento de configuración
    const configRef = doc(db, "cotizador_config", "bolivia")
    await setDoc(configRef, cotizadorConfig)

    console.log("✅ Configuración del cotizador creada exitosamente")
    console.log(`📊 Paneles: ${cotizadorConfig.panels.length}`)
    console.log(`🔋 Baterías: ${cotizadorConfig.batteries.length}`)
    console.log(`⚡ Inversores: ${cotizadorConfig.inverters.length}`)
    console.log(`🗺️ Departamentos: ${Object.keys(cotizadorConfig.radiation_by_department).length}`)
    console.log(`💱 Tipo de cambio: ${cotizadorConfig.costFactors.exchangeRate} Bs/USD`)
    console.log("\n💰 Costos fijos configurados:")
    Object.entries(cotizadorConfig.costFactors.fixedCosts).forEach(([key, value]) => {
      console.log(`   • ${key}: $${value}`)
    })
    console.log("\n🚚 Transporte por kg configurado:")
    Object.entries(cotizadorConfig.costFactors.transportPerKg).forEach(([dept, cost]) => {
      console.log(`   • ${dept}: $${cost}/kg`)
    })
    console.log("\n⚡ Tarifas eléctricas configuradas:")
    console.log(`   • Residencial: ${cotizadorConfig.electricityRates.residential.tiers.length} rangos`)
    console.log(`   • Comercial: ${cotizadorConfig.electricityRates.commercial.tiers.length} rangos`)
    console.log(`   • Industrial: Tarifa plana ${cotizadorConfig.electricityRates.industrial.flatEstimate_Bs_per_kWh} Bs/kWh`)

    process.exit(0)
  } catch (error) {
    console.error("❌ Error al crear configuración del cotizador:", error)
    process.exit(1)
  }
}

// Ejecutar el seed
seedCotizadorConfig()
