export interface SimplePokemon {
    id: string;
    name: string;
}